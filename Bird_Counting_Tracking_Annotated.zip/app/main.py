
from fastapi import FastAPI, UploadFile, File
from typing import Optional
import shutil, json, os
import cv2
import numpy as np
from ultralytics import YOLO
from collections import defaultdict

app = FastAPI()
model = YOLO("yolov8n.pt")

@app.get("/health")
def health():
    return {"status": "OK"}

def iou(boxA, boxB):
    xA = max(boxA[0], boxB[0])
    yA = max(boxA[1], boxB[1])
    xB = min(boxA[2], boxB[2])
    yB = min(boxA[3], boxB[3])
    inter = max(0, xB - xA) * max(0, yB - yA)
    areaA = (boxA[2]-boxA[0])*(boxA[3]-boxA[1])
    areaB = (boxB[2]-boxB[0])*(boxB[3]-boxB[1])
    return inter / float(areaA + areaB - inter + 1e-6)

@app.post("/analyze_video")
async def analyze_video(
    video: UploadFile = File(...),
    fps_sample: Optional[int] = 5,
    conf_thresh: Optional[float] = 0.4,
    iou_thresh: Optional[float] = 0.3
):
    os.makedirs("outputs", exist_ok=True)
    video_path = f"outputs/{video.filename}"
    with open(video_path, "wb") as f:
        shutil.copyfileobj(video.file, f)

    cap = cv2.VideoCapture(video_path)
    fps = int(cap.get(cv2.CAP_PROP_FPS))
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    out_video = cv2.VideoWriter(
        "outputs/annotated_video.mp4",
        cv2.VideoWriter_fourcc(*"mp4v"),
        fps,
        (width, height)
    )

    next_id = 0
    tracks = {}
    weight_areas = defaultdict(list)
    counts = []
    frame_id = 0

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        if frame_id % max(1, fps // fps_sample) == 0:
            results = model(frame, conf=conf_thresh, classes=[14])
            detections = []
            if results[0].boxes:
                for b in results[0].boxes.xyxy.cpu().numpy():
                    detections.append(b)

            updated_tracks = {}
            for det in detections:
                matched = False
                for tid, tbox in tracks.items():
                    if iou(det, tbox) > iou_thresh:
                        updated_tracks[tid] = det
                        matched = True
                        area = (det[2]-det[0])*(det[3]-det[1])
                        weight_areas[tid].append(area)
                        break
                if not matched:
                    updated_tracks[next_id] = det
                    area = (det[2]-det[0])*(det[3]-det[1])
                    weight_areas[next_id].append(area)
                    next_id += 1

            tracks = updated_tracks

            for tid, box in tracks.items():
                x1,y1,x2,y2 = map(int, box)
                cv2.rectangle(frame,(x1,y1),(x2,y2),(0,255,0),2)
                cv2.putText(frame,f"ID {tid}",(x1,y1-10),
                            cv2.FONT_HERSHEY_SIMPLEX,0.6,(0,255,0),2)

            counts.append({
                "timestamp_sec": int(frame_id/fps),
                "bird_count": len(tracks)
            })

        cv2.putText(frame, f"Count: {len(tracks)}", (20,40),
                    cv2.FONT_HERSHEY_SIMPLEX,1,(255,0,0),2)

        out_video.write(frame)
        frame_id += 1

    cap.release()
    out_video.release()

    per_bird = [
        {
            "track_id": tid,
            "weight_index": round(float(np.mean(areas)),2),
            "confidence": 0.8
        }
        for tid, areas in weight_areas.items()
    ]

    response = {
        "counts": counts[:30],
        "tracks_sample": per_bird[:5],
        "weight_estimates": {
            "unit": "index",
            "per_bird": per_bird[:10],
            "aggregate": {
                "mean_weight_index": round(
                    float(np.mean([p["weight_index"] for p in per_bird])),2
                ) if per_bird else 0.0
            }
        },
        "artifacts": {
            "annotated_video": "outputs/annotated_video.mp4"
        }
    }

    with open("outputs/sample_response.json","w") as f:
        json.dump(response,f,indent=2)

    return response
