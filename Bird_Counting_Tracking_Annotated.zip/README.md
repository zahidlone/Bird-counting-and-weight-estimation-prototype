
# Bird Counting & Weight Estimation (Tracking + Annotated Video)

## Approach
- YOLOv8 for bird detection
- IoU-based multi-object tracking (stable IDs)
- Avoids double counting
- Weight proxy = bounding box area average

## Outputs
- Annotated video with bounding boxes, IDs, count overlay
- JSON response with counts and weight estimates

## Run
pip install -r requirements.txt
uvicorn app.main:app --reload
